'use strict';
// 3D VECTOR
class Vector {
    constructor(x = 0, y = 0, z = 0, w = 0) {
        this.x = x;
        this.y = y;
        this.z = z;
        this.w = w;
    }
    negative() {
        return new Vector(-this.x, -this.y, -this.z, -this.w);
    }
    add(v) {
        if (v instanceof Vector) return new Vector(this.x + v.x, this.y + v.y, this.z + v.w, this.z + v.w);
        else return new Vector(this.x + v, this.y + v, this.z + v, this.w + v);
    }
    subtract(v) {
        if (v instanceof Vector) return new Vector(this.x - v.x, this.y - v.y, this.z - v.z, this.w - v.w);
        else return new Vector(this.x - v, this.y - v, this.z - v, this.w - v);
    }
    multiply(v) {
        if (v instanceof Vector) return new Vector(this.x * v.x, this.y * v.y, this.z * v.z, this.w * v.w);
        else return new Vector(this.x * v, this.y * v, this.z * v, this.w * v);
    }
    divide(v) {
        if (v instanceof Vector) return new Vector(this.x / v.x, this.y / v.y, this.z / v.z, this.w / v.w);
        else return new Vector(this.x / v, this.y / v, this.z / v, this.w / v);
    }
    equals(v) {
        return this.x == v.x && this.y == v.y && this.z == v.z && this.w == v.w;
    }
    dot(v) {
        return this.x * v.x + this.y * v.y + this.z * v.z + this.w * v.w;
    }
    cross(v) {
        return new Vector(
            this.y * v.z - this.z * v.y,
            this.z * v.x - this.x * v.z,
            this.x * v.y - this.y * v.x
        );
    }
    length() {
        return Math.sqrt(this.dot(this));
    }
    unit() {
        return this.divide(this.length());
    }
    min() {
        return Math.min(Math.min(this.x, this.y), this.z);
    }
    max() {
        return Math.max(Math.max(this.x, this.y), this.z);
    }
    toAngles() {
        return {
            theta: Math.atan2(this.z, this.x),
            phi: Math.asin(this.y / this.length())
        };
    }
    angleTo(a) {
        return Math.acos(this.dot(a) / (this.length() * a.length()));
    }
    toArray(n) {
        return [this.x, this.y, this.z].slice(0, n || 3);
    }
    clone() {
        return new Vector(this.x, this.y, this.z);
    }
    init(x, y, z) {
        this.x = x; this.y = y; this.z = z;
        return this;
    }
    // static routines
    static negative(a, b) {
        b.x = -a.x; b.y = -a.y; b.z = -a.z, b.w = -a.w;
        return b;
    }
    static add(a, b, c) {
        if (b instanceof Vector) { c.x = a.x + b.x; c.y = a.y + b.y; c.z = a.z + b.z;  c.w = a.w + b.w;}
        else { c.x = a.x + b; c.y = a.y + b; c.z = a.z + b; c.w = a.w + b;}
        return c;
    }
    static subtract(a, b, c) {
        if (b instanceof Vector) { c.x = a.x - b.x; c.y = a.y - b.y; c.z = a.z - b.z; c.w = a.w - b.w; }
        else { c.x = a.x - b; c.y = a.y - b; c.z = a.z - b; c.w = a.w - b; }
        return c;
    }
    static multiply(a, b, c) {
        if (b instanceof Vector) { c.x = a.x * b.x; c.y = a.y * b.y; c.z = a.z * b.z; c.w = a.w * b.w; }
        else { c.x = a.x * b; c.y = a.y * b; c.z = a.z * b; c.w = a.w * b; }
        return c;
    }
    static divide(a, b, c) {
        if (b instanceof Vector) { c.x = a.x / b.x; c.y = a.y / b.y; c.z = a.z / b.z; c.w = a.w / b.w; }
        else { c.x = a.x / b; c.y = a.y / b; c.z = a.z / b; c.w = a.w / b; }
        return c;
    }
    static cross(a, b, c) {
        c.x = a.y * b.z - a.z * b.y;
        c.y = a.z * b.x - a.x * b.z;
        c.z = a.x * b.y - a.y * b.x;
        return c;
    }
    static unit(a, b) {
        var length = a.length();
        b.x = a.x / length;
        b.y = a.y / length;
        b.z = a.z / length;
        return b;
    }
    static fromAngles(theta, phi) {
        return new Vector(Math.cos(theta) * Math.cos(phi), Math.sin(phi), Math.sin(theta) * Math.cos(phi));
    }
    static randomDirection() {
        return Vector.fromAngles(Math.random() * Math.PI * 2, Math.asin(Math.random() * 2 - 1));
    }
    static min(a, b) {
        return new Vector(Math.min(a.x, b.x), Math.min(a.y, b.y), Math.min(a.z, b.z));
    }
    static max(a, b) {
        return new Vector(Math.max(a.x, b.x), Math.max(a.y, b.y), Math.max(a.z, b.z));
    }
    static lerp(a, b, fraction) {
        return b.subtract(a).multiply(fraction).add(a);
    }
    static fromArray(a = [[0,0,0],[0,0,0],[0,0,0]]) {
        return new Vector(a[0], a[1], a[2]);
    }
    static angleBetween(a, b) {
        return a.angleTo(b);
    };
}
exports.Vector = Vector;

class Matrix {
    /**
     * @constructor
     * @param 2D array with row/column data type: multidymensional array
     */
    constructor(matrix = [[0,0],[0,0]], rows = 2, cols = 2) {
        if (matrix == null) {
            // in case we would like to create out onwn matrix, we define its rows, and columns
            this._matrix = [];
            this.rows = rows;
            this.cols = cols;
            for (let i = 0; i < rows; i += 1) {
                this._matrix[i] = [];
                for (let j = 0; j < cols; j += 1) {
                    this._matrix[i][j] = 0;
                }
            }
        } else {
            this._matrix = matrix;
            this.rows = this._matrix.length;
            this.cols = this._matrix[0].length;
        }
    }
    _each(func) {
        for(var i = 0; i < this._matrix.length; i++){
            for(var j = 0; j < this._matrix[0].length; j++){
                func(i,j);
            }
        }
    }
    numColumns() {
        if(!this._matrix) return null;
        return this._matrix[0].length;
    }
    static numColumns(m) {
        if(!m._matrix) return null;
        return m._matrix[0].length;
    }
    numRows(){
        if(!this._matrix) return null;
        return this._matrix.length;
    }
    static numRows(m){
        if(!m._matrix) return null;
        return m._matrix.length;
    }
    getMatrix(){
        return this._matrix;
    }
    setMatrix(newMatrix){
        this._matrix = newMatrix;
        return this;
    }
    checkSquare(){
        if(this.numColumns() === this.numRows()){
            return true;
        }
        return false;
    }
    static checkSquare(m){
        if(m.numColumns() === m.numRows()){
            return true;
        }
        return false;
    }
    add(addMatrixObj){
        var addMatrix = addMatrixObj.getMatrix();
        if(this.numColumns() != addMatrixObj.numColumns() || this.numRows() != addMatrixObj.numRows() ){
            throw 'Matrices must be of equal dimensions to add';
        }
        this._each(function(row,column){
            this._matrix[row][column] += addMatrix[row][column];
        }.bind(this));
        return this;
    }
    static add(m, addMatrixObj){
        var addMatrix = addMatrixObj.getMatrix();
        if(m.numColumns() != addMatrixObj.numColumns() || m.numRows() != addMatrixObj.numRows() ){
            throw 'Matrices must be of equal dimensions to add';
        }
        m._each(function(row,column){
            m._matrix[row][column] += addMatrix[row][column];
        }.bind(m));
        return m;
    }
    subtract(addMatrixObj){
        var subtractMatrix = addMatrixObj.getMatrix();
        if(this.numColumns() != addMatrixObj.numColumns() || this.numRows() != addMatrixObj.numRows() ){
            throw 'Matrices must be of equal dimensions to add';
        }
        this._each(function(row,column){
            this._matrix[row][column] -= subtractMatrix[row][column];
        }.bind(this));
        return this;
    }
    static subtract(m, addMatrixObj){
        var subtractMatrix = addMatrixObj.getMatrix();
        if(m.numColumns() != addMatrixObj.numColumns() || m.numRows() != addMatrixObj.numRows() ){
            throw 'Matrices must be of equal dimensions to add';
        }
        m._each(function(row,column){
            m._matrix[row][column] -= subtractMatrix[row][column];
        }.bind(m));
        return m;
    }
    multiply(aMatrix){
        var m2 = aMatrix.getMatrix();
        var m1 = this._matrix;
        console.log("m1",m1,"m2",m2);

        var result = [];
        for (var i = 0; i < m1.length; i++) {
            result[i] = [];
            for (var j = 0; j < m2[0].length; j++) {
                var sum = 0;
                if (m1[0].length) {
                    for (var k = 0; k < m1[0].length; k++) {
                        if (m2[k].length) {
                            sum += m1[i][k] * m2[k][j];
                        } else {
                            sum += m1[i][k] * m2[0];
                        }
                    }
                } else {
                    for (var k = 0; k < m1[0].length; k++) {
                        if (m2[k].length) {
                            sum += m1[i][0] * m2[k][j];
                        } else {
                            sum += m1[i][0] * m2[0];
                        }
                    }
                }
                result[i][j] = sum;
            }
        }
        this._matrix = result;
        return this;
    }
    static multiply(m, aMatrix){
        var m2 = aMatrix.getMatrix();
        var m1 = m._matrix;

        var result = [];
        for (var i = 0; i < m1.length; i++) {
            result[i] = [];
            for (var j = 0; j < m2[0].length; j++) {
                var sum = 0;
                if (m1[0].length) {
                    for (var k = 0; k < m1[0].length; k++) {
                        if (m2[k] && m2[k].length) {
                            sum += m1[i][k] * m2[k][j];
                        } else {
                            sum += m1[i][k] * m2[0];
                        }
                    }
                } else {
                    for (var k = 0; k < m1[0].length; k++) {
                        if (m2[k].length) {
                            sum += m1[i][0] * m2[k][j];
                        } else {
                            sum += m1[i][0] * m2[0];
                        }
                    }
                }
                result[i][j] = sum;
            }
        }
        m._matrix = result;
        return m;
    }
    scalarMultiply(scalar){
        if(typeof scalar != 'number') throw 'Scalar must be a number';
        this._each(function(row,column){
            this._matrix[row][column] *= scalar;
        }.bind(this));
        return this;
    }
    static scalarMultiply(m, scalar){
        if(typeof scalar != 'number') throw 'Scalar must be a number';
        m._each(function(row,column){
            m._matrix[row][column] *= scalar;
        }.bind(m));
        return m;
    }
    transpose(){
        var transposedMatrix = [];
        for(var i = 0; i < this.numColumns(); i++){
            transposedMatrix.push([]);
        }
        this._each(function(row,column){
            transposedMatrix[column][row] = this._matrix[row][column]
        }.bind(this));
        this._matrix = transposedMatrix;
        return this;
    }
    static transpose(m){
        var transposedMatrix = [];
        for(var i = 0; i < m.numColumns(); i++){
            transposedMatrix.push([]);
        }
        m._each((row,column) => {
            transposedMatrix[column][row] = m._matrix[row][column]
        }).bind(m);
        m._matrix = transposedMatrix;
        return m;
    }
    determinant(){
        var s;
        var det = 0;
        var k = this.numColumns();
        if(k != this.numRows()){
            throw 'Matrices must be of equal dimensions to multiply';
        }
        const calcDet = (A) => {
            if (A.length == 1) {
                return A[0][0];
            }
            if (A.length == 2) {
                det =  A[0][0] * A[1][1] - A[1][0] * A [0][1];
                return det;
            }
            for (var i = 0; i < k; i++) {
                var smaller = new Array(A.length - 1);
                for (var h = 0; h < smaller.length; h++) {
                    smaller[h] = new Array(A.length - 1);
                }
                for(var a = 1; a < A.length; a++) {
                    for(var b = 0; b < A.length; b++) {
                        if (b < i) {
                            smaller[a - 1][b] = A[a][b];
                        } else if (b > i) {
                            smaller[a - 1][b - 1] = A[a][b];
                        }
                    }
                }
                if(i % 2 == 0) {s = 1;}
                else {s = -1;}
                det += s * A[0][i] * (calcDet(smaller));
            }
            return det
        }
        return calcDet(this._matrix);
    }
    static determinant(m){
        var s;
        var det = 0;
        var k = m.numColumns();
        if(k != m.numRows()){
            throw 'Matrices must be of equal dimensions to multiply';
        }
        const calcDet = (A) => {
            if (A.length == 1) {
                return A[0][0];
            }
            if (A.length == 2) {
                det =  A[0][0] * A[1][1] - A[1][0] * A [0][1];
                return det;
            }
            for (var i = 0; i < k; i++) {
                var smaller = new Array(A.length - 1);
                for (var h = 0; h < smaller.length; h++) {
                    smaller[h] = new Array(A.length - 1);
                }
                for(var a = 1; a < A.length; a++) {
                    for(var b = 0; b < A.length; b++) {
                        if (b < i) {
                            smaller[a - 1][b] = A[a][b];
                        } else if (b > i) {
                            smaller[a - 1][b - 1] = A[a][b];
                        }
                    }
                }
                if(i % 2 == 0) {s = 1;}
                else {s = -1;}
                det += s * A[0][i] * (calcDet(smaller));
            }
            return det
        }
        return calcDet(m._matrix);
    }
    trace(){
        if(!this.checkSquare()){
            throw "Matrix must be square";
        }
        var trace = 0;
        this._each((row,col) => {
            if(row === col){ trace += this._matrix[row][col];}
        }).bind(this);
        return trace;
    }
    static trace(m){
        if(!m.checkSquare()){
            throw "Matrix must be square";
        }
        var trace = 0;
        m._each((row,col) => {
            if(row === col){ trace += m._matrix[row][col];}
        }).bind(m);
        return trace;
    }
    _makeIdentity(){
        var matrix = [];
        for(var i = 0; i < this._matrix.length ; i++){
            matrix.push([]);
            for(var j = 0; j < this._matrix.length ; j++){
                if(i===j){
                    matrix[i].push(1);
                } else{
                    matrix[i].push(0);
                }
            }
        }
        //console.log(new Matrix(matrix));
        return matrix;
    }
    identity() {
        return new Matrix(this._makeIdentity());
    }
    static identity(m) {
        return new Matrix(m._makeIdentity());
    }
    _RREF(matrix){
        var lead = 0;
        var rowCount = matrix.length;
        var colCount = matrix[0].length;
        for(var r = 0; r < rowCount; r++){
            if(colCount < lead){
                return matrix;
            }
            var i = r;
            while(matrix[i][lead] == 0){
                i++;
                if(rowCount == i){
                    i=r;
                    lead++
                    if(colCount === lead){
                        return matrix;
                    }
                }
            }
            matrix[i] = [matrix[r], matrix[r] = matrix[i]][0]; //bwhahahha
            var val = matrix[r][lead];
            for(var j = 0; j < colCount; j++){
                matrix[r][j] = matrix[r][j] / val;
            }
            for(var i = 0 ; i < rowCount; i++){
                if(i != r){
                    var val = matrix[i][lead];
                    for(var t = 0; t < colCount ; t++){
                        matrix[i][t] -= val * matrix[r][t];
                    }
                }
            }
            lead++;
        }
        return matrix
    }
    inverse(){
        var m = this.numColumns()
        var identity = this._makeIdentity(m)
        var adjMatrix = this.getMatrix();

        for(var i =0 ; i < m ; i++){
            adjMatrix[i] = adjMatrix[i].concat(identity[i]);
        }

        var rRef = this._RREF(adjMatrix);
        var iMatrix = [];

        for(var i = 0; i < m; i++){
            iMatrix.push([]);
            for(var j = 0; j < m ; j++){
                iMatrix[i].push(rRef[i][j+m]);
            }
        }
        this._matrix = iMatrix;
        return this;
    }
    static inverse(n){
        var m = n.numColumns()
        var identity = n._makeIdentity(m)
        var adjMatrix = n.getMatrix();

        for(var i =0 ; i < m ; i++){
            adjMatrix[i] = adjMatrix[i].concat(identity[i]);
        }

        var rRef = n._RREF(adjMatrix);
        var iMatrix = [];

        for(var i = 0; i < m; i++){
            iMatrix.push([]);
            for(var j = 0; j < m ; j++){
                iMatrix[i].push(rRef[i][j+m]);
            }
        }
        n._matrix = iMatrix;
        return n;
    }
    rotateX(rad){
        var rotation = new Matrix([
                                  [1,0,0,0],
                                  [0,Math.cos(rad),-1*Math.sin(rad),0],
                                  [0,Math.sin(rad),Math.cos(rad),0],
                                  [0,0,0,1]
                                ]);
        this.multiply(rotation);
        return this;
    }
    static rotateX(m, rad){
        var rotation = new Matrix([
                                  [1,0,0,0],
                                  [0,Math.cos(rad),-1*Math.sin(rad),0],
                                  [0,Math.sin(rad),Math.cos(rad),0],
                                  [0,0,0,1]
                                ]);
        m.multiply(rotation);
        return m;
    }
    rotateY(rad){
        var rotation = new Matrix([
                                  [Math.cos(rad),0,Math.sin(rad),0],
                                  [0,1,0,0],
                                  [-1*Math.sin(rad),0,Math.cos(rad),0],
                                  [0,0,0,1]
                                ]);
        this.multiply(rotation);
        return this;
    }
    static rotateY(m, rad){
        var rotation = new Matrix([
                                  [Math.cos(rad),0,Math.sin(rad),0],
                                  [0,1,0,0],
                                  [-1*Math.sin(rad),0,Math.cos(rad),0],
                                  [0,0,0,1]
                                ]);
        m.multiply(rotation);
        return m;
    }
    rotateZ(rad){
        var rotation = new Matrix([
                                  [Math.cos(rad),-1*Math.sin(rad),0,0],
                                  [Math.sin(rad),Math.cos(rad),0,0],
                                  [0,0,1,0],
                                  [0,0,0,1]
                                ]);
        this.multiply(rotation);
        return this;
    }
    static rotateZ(m, rad){
        var rotation = new Matrix([
                                  [Math.cos(rad),-1*Math.sin(rad),0,0],
                                  [Math.sin(rad),Math.cos(rad),0,0],
                                  [0,0,1,0],
                                  [0,0,0,1]
                                ]);
        m.multiply(rotation);
        return m;
    }
    translateX(x){
        // var translation = new Matrix([
        //                                 [1,0,0,0],
        //                                 [0,1,0,0],
        //                                 [0,0,1,0],
        //                                 [x,0,0,1]
        //                               ]);
        this._matrix[3][0] += x;
        return this;
    }
    static translateX(m, x){
        // var translation = new Matrix([
        //                                 [1,0,0,0],
        //                                 [0,1,0,0],
        //                                 [0,0,1,0],
        //                                 [x,0,0,1]
        //                               ]);
        m._matrix[3][0] += x;
        return m;
    }
    translateY(y){
        // var translation = new Matrix([
        //                                 [1,0,0,0],
        //                                 [0,1,0,0],
        //                                 [0,0,1,0],
        //                                 [0,y,0,1]
        //                               ]);
        this._matrix[3][1] += y;
        return this;
    }
    static translateY(m, y){
        // var translation = new Matrix([
        //                                 [1,0,0,0],
        //                                 [0,1,0,0],
        //                                 [0,0,1,0],
        //                                 [0,y,0,1]
        //                               ]);
        m._matrix[3][1] += y;
        return m;
    }
    translateZ(z){
        // var translation = new Matrix([
        //                                 [1,0,0,0],
        //                                 [0,1,0,0],
        //                                 [0,0,1,0],
        //                                 [0,0,z,1]
        //                               ]);
        this._matrix[3][2] += z;
        return this;
    }
    static translateZ(m, z){
        // var translation = new Matrix([
        //                                 [1,0,0,0],
        //                                 [0,1,0,0],
        //                                 [0,0,1,0],
        //                                 [0,0,z,1]
        //                               ]);
        m._matrix[3][2] += z;
        return m;
    }
    //copyMatrix = function(){
    clone(){
        var copy = [];
        for(var i = 0; i < this.numRows(); i++){
            copy.push([]);
            for(var j = 0; j < this.numColumns(); j++){
                copy[i].push(this._matrix[i][j]);
            }
        }
        return copy;
    }
    static clone(m){
        var copy = [];
        for(var i = 0; i < m.numRows(); i++){
            copy.push([]);
            for(var j = 0; j < m.numColumns(); j++){
                copy[i].push(m._matrix[i][j]);
            }
        }
        return copy;
    }
    toString() {
        var s = "";
        this._each(function(row,column) {
            if(row===this._matrix[0].length-1 && column===this._matrix.length-1) {
                s+=this._matrix[row][column].toFixed(15);
            }else{
                s+= this._matrix[row][column].toFixed(15) + ",";
            }
        }.bind(this));
        return s
    }
    print() {
        let mstr = "==[";
        mstr += `${this.rows}`+"x"+`${this.cols}`;
        mstr += "]========\n";
        for (let i = 0; i < this.rows; i += 1) {
            for (let j = 0; j < this.cols; j += 1) {
                let val = this._matrix[i][j].toFixed(12);
                val = (val >= 0 ? " "+val : val);
                if (j == 0) {
                    mstr += "| " + val;
                } else if (j == this.cols-1) {
                    mstr += " " +  val + " |";
                } else {
                    mstr += " " + val;
                }
            }
            mstr += "\n";
        }
        console.log(mstr);
    }
}
exports.Matrix = Matrix;

/*
let angle = 315;
let theta = angle * Math.PI/180.0;

const RX = [[1,0,0],[0,Math.cos(theta),-1*Math.sin(theta)],[0,Math.sin(theta),Math.cos(theta)]];
const RY = [[Math.cos(theta),1,Math.sin(theta)],[0,1,0],[-1*Math.sin(theta),0,Math.cos(theta)]];
const RZ = [[Math.cos(theta),-1*Math.sin(theta),0],[Math.sin(theta),Math.cos(theta),0],[0,0,1]];


let M = [[1,0,0],[0,1,0],[0,0,1]];


let V = [1,1,1];

let M_RX = new Matrix(RX);
let M_RY = new Matrix(RY);
let M_RZ = new Matrix(RZ);

M_RX.print();
M_RY.print();
M_RZ.print();
*/
